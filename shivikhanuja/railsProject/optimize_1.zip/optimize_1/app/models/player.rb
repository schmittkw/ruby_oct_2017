class Player < ActiveRecord::Base
  belongs_to :team
end
