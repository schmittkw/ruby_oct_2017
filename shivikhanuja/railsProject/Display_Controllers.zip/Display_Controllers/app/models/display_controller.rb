class DisplayController < ActiveRecord::Base
end
