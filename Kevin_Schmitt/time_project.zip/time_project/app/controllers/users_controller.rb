class UsersController < ApplicationController

    def begin
        render 'users/first_page'
    end


end
