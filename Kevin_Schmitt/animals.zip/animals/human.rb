require_relative 'mammal'
class Human < Mammal
    puts 'I am in the human file'
  # previous code removed for brevity
end
human = Human.new