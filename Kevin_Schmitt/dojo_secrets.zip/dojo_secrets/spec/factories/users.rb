FactoryGirl.define do
  factory :user do
    name "Homer Simpson"
    email "donUTs@mmm.com"
    password "password"
  end
end
