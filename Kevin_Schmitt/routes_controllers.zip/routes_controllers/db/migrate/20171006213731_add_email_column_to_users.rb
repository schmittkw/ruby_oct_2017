class AddEmailColumnToUsers < ActiveRecord::Migration
  def change
  end
end
