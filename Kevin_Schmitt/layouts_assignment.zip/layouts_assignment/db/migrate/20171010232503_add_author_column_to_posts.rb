class AddAuthorColumnToPosts < ActiveRecord::Migration
  def change
  end
end
