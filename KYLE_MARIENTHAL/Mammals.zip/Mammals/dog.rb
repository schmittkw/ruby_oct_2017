require_relative 'mammal'
class Dog < Mammal
  attr_accessor
  def initialize (health)
    super(health)
  end
  def pet
    @health += 5
    self
  end

  def walk
    @health -= 1
    self
  end

  def run
    @health -= 10
    self
  end

end
dog = Dog.new 150

puts dog.walk.walk.walk.run.run.pet.display_health
