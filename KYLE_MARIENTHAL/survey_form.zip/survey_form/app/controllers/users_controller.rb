class UsersController < ApplicationController
  def index
    session[:views] ||= 0
  end


  def process_survey
    # increment the session views upon submission of the form
    session[:views] += 1
    # Save the post data (params[:survey]) to session
    session[:user_info] = params[:survey]
    # save the success message to flash to show it one time
    flash[:success] = "Thanks for cooperating, you have submitted this form #{session[:views]} times. you can stop now."
    return redirect_to users_show_path




    # @user = User.new(user_params)
    # if @user.valid?
    #   @user.save
    #   return redirect_to users_show_path
    # end
  end

  def show
    puts "*****yer in the show method*****"
    @user_info = session[:user_info]
  end
end
