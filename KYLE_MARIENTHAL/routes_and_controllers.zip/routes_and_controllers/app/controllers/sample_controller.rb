class SampleController < ApplicationController

  def index
    puts "***********************You are in Index********************"
    render text: "What do you want me to say?"
  end

  def hello
    puts "***********************You are in Hello********************"
    render text: "Hello CodingDojo"
  end

  def say
    puts "***********************You are in Say********************"
    unless params[:name]
      render text: "Saying Hello!"
    else
      if params[:name] == "michael"
        redirect_to "/say/hello/joe"
      else
        render text: "Saying Hello #{params[:name]}!"
      end
    end
  end

  def times
    puts "***********************You are in times********************"
    session[:count] ||= 0
    render text: "You have visited this #{session[:count]+= 1} time(s)"
  end

  def restart
    puts "***********************You are in restart********************"
    reset_session
    render text: "You've destroyed the session"
  end

end
